@echo off
REM Module 1: tao toan bo cay thu muc bang 1 lenh mkdir
mkdir greentech-system\docs greentech-system\scripts ^
  greentech-system\data greentech-system\backup
cd greentech-system
echo. > .env
attrib +h .env
tree /f
